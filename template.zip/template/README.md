<h2 align="center">js-plugin-cli</h2>
<p align="center">
A lightweight javascript plugin CLI.
</p>
<p align="center">

<p align="center">
<img src="https://img.shields.io/badge/build-passing-brightgreen?style=flat-square" alt="Build Status">
<img src="https://img.shields.io/github/package-json/v/zpfz/js-plugin-cli?style=flat-square&color=orange" alt="Version">
<img src="https://img.shields.io/badge/license-MIT-brightgreen?style=flat-square&color=blue" alt="MIT">
<img alt="npm" src="https://img.shields.io/npm/dt/js-plugin-cli?style=flat-square&color=red" alt="downloads">
</p>

</p>

